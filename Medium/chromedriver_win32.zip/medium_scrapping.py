from selenium import webdriver
from bs4 import BeautifulSoup
from time import sleep

browser = webdriver.Chrome('./chromedriver.exe')
browser.get('https://medium.com/search?q=Python%20and%20Django')

blogs = browser.find_elements_by_class_name('u-paddingTop20')

all_links = []
for blog in blogs:
    details = BeautifulSoup(blog.get_attribute('innerHTML'), 'html.parser')
    link = str(details.find('a', class_ = 'button--smaller'))
    link = (link[link.find('href=') + len('href="'):link.find('?source=',link.find('href=') ) ]).replace("\n", "").strip()
    all_links.append(link)
        
for link in all_links:
    details = browser.get(link)
    ### Scrape Details....
